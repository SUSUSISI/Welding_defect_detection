import errno
import os

import FaDAm as fd
from datetime import datetime
import random as rd
import numpy as np
import normal_data_generator
import machanical_error_data_generator
import porosity_data_generator
import undercurrent_data_generator
import undercut_data_generator
import threading
import time
import FaDAm as fd


class WeldingMachine(threading.Thread):
    base_current = 260
    base_voltage = 30
    base_wire_feed = 8.1

    init_current = 8.0
    init_voltage = 0.0
    init_wire_feed = 0.0

    process_id = 1

    current_data = None
    next_data = None
    port_current = None
    port_voltage = None
    port_wire_feed = None

    def __init__(self, name, error_rate):
        threading.Thread.__init__(self)
        self.name = name
        self.error_rate = error_rate
        self.path = "data/" + self.name + "_" + datetime.now().strftime('%Y_%m_%d_%H%M%S') + "/"

    def set_base(self, current, voltage, wire_feed):
        self.base_current = current
        self.base_voltage = voltage
        self.base_wire_feed = wire_feed

    def set_init(self, current, voltage, wire_feed):
        self.init_current = current
        self.init_voltage = voltage
        self.init_wire_feed = wire_feed

    def warm_up(self):
        self.current_data = self.generate_welding_data()
        self.next_data = self.generate_welding_data()

    def set_port(self, port_current, port_voltage, port_wire_feed):
        self.port_current = port_current
        self.port_voltage = port_voltage
        self.port_wire_feed = port_wire_feed

    def send_data(self, data):
        current = round(data[0], 1)
        voltage = round(data[1], 1)
        wire_feed = round(data[2], 1)

        print("-----------------------------------------------")
        print(datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f'))
        print("current : ", current)
        print("voltage : ", voltage)
        print("wire_feed : ", wire_feed)
        print("-----------------------------------------------")

    def run(self):
        self.warm_up()
        while True:
            self.current_data.time = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')
            self.current_data.process_id = self.process_id

            save_thread = threading.Thread(target=save_data, args=(self.current_data, self.path))
            save_thread.run()

            for i in self.current_data.data:
                self.send_data(i)
                time.sleep(0.2)

            self.current_data = self.next_data
            self.current_data = self.generate_welding_data()

    def generate_welding_data(self, duration=None):
        if duration is None:
            duration = rd.randint(60, 600)

        if rd.random() >= self.error_rate:
            return normal_data_generator.generate(self.base_current, self.base_voltage, self.base_wire_feed,
                                                  self.init_current, self.init_voltage, self.init_wire_feed, duration)
        else:
            error_case = rd.randint(1, 4)
            if error_case == 1:
                return machanical_error_data_generator.generate(self.base_current, self.base_voltage,
                                                                self.base_wire_feed,
                                                                self.init_current, self.init_voltage,
                                                                self.init_wire_feed,
                                                                duration)
            elif error_case == 2:
                return porosity_data_generator.generate(self.base_current, self.base_voltage, self.base_wire_feed,
                                                        self.init_current, self.init_voltage, self.init_wire_feed,
                                                        duration)
            elif error_case == 3:
                return undercut_data_generator.generate(self.base_current, self.base_voltage, self.base_wire_feed,
                                                        self.init_current, self.init_voltage, self.init_wire_feed,
                                                        duration)
            elif error_case == 4:
                return undercurrent_data_generator.generate(self.base_current, self.base_voltage, self.base_wire_feed,
                                                            self.init_current, self.init_voltage, self.init_wire_feed,
                                                            duration)


def save_data(data, path):
    print(path)
    try:
        if not (os.path.isdir(path)):
            os.makedirs(path)

    except OSError as e:
        if e.errno != errno.EEXIST:
            print("Failed to create directory!!!!!")
            raise

    file_path = path + "process_" + str(data.process_id) + ".csv"
    fd.GTAW.save_welding_data(data, file_path)
