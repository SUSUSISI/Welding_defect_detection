$(document).ready(function() {
    // Setup - add a text input to each footer cell
    //$('#tb_example thead tr').clone(true).appendTo( '#tb_example thead' );

    //$('#tb_example thead tr:eq(1) th').each( function (i) {
       //var index_tb = [0, 3, 6, 7];
      // if (i in index_tb) {
       //   var title = $(this).text();
          //$(this).html( '<input type="text" style="width:60%" placeholder="Filter'+'" />' );

         $( 'input', this ).on( 'keyup change', function () {
          if ( table.column(i).search() !== this.value ) {
             table
            .column(i)
            .search( this.value )
            .draw();
            }
        });
     //   }   
   // } );

    var table = $('#tb_example').DataTable( {
        ajax : {url : "MOCK_DATA.json", dataSrc: ''},

        columns: [
            {targets:0, data: "id"},
            {targets:1, data: "first_name"},
            {targets:2, data: "last_name"}, 
            {targets:3, data: "email"}, 
            {targets:4, data: "gender"}, 
            {targets:5, data: "date"},
            {targets:6, data: "ip_address"},
            {targets:7, data:"money"}
        ],

        orderCellsTop: true,
        fixedHeader: true,
        responsive: true,
        paging: false,
        scrollY: 200,
        scrollX: true,
        lengthChange: false,
        ordering: true,
        searching: false,
        
        /*dom: "Bfrtip",
        buttons: [{
            extend: 'csvHtml5',
            text: 'Download',
            style: '',
            footer: true,
            className: 'exportBtn btn btn-danger btn-sm'
        }]*/

    } );

    table.buttons().container().appendTo($('#test_space'));

    $.fn.dataTable.ext.search.push(
        function(settings, data, dataIndex){
            var min = Date.parse($('#fromDate').val());
            var max = Date.parse($('#toDate').val());
            var targetDate = Date.parse(data[5]);

            if( (isNaN(min) && isNaN(max) ) || 
                (isNaN(min) && targetDate <= max )|| 
                ( min <= targetDate && isNaN(max) ) ||
                ( targetDate >= min && targetDate <= max) ){ 
                    return true;
            }
            return false;
        }
    )

    $('#toDate, #fromDate').unbind().bind('keyup',function(){
        table.draw();
    })
});