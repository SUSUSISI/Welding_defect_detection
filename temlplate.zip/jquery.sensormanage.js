$(document).ready(function() {
    var i = 1; 
    $('#myModal').on('click','#paramsOkay', function (e) {
        //console.log($('#sensor_name').val());
        //console.log(e);
        //$('#tb_sensor').append($('#sensor_name').val());
        var my_tbody = document.getElementById('my-tbody');
        // var row = my_tbody.insertRow(0); // 상단에 추가
        var row = my_tbody.insertRow( my_tbody.rows.length ); // 하단에 추가
        
        var cell1 = row.insertCell(0);
        var cell2 = row.insertCell(1);
        var cell3 = row.insertCell(2);
        var cell4 = row.insertCell(3);
        var cell5 = row.insertCell(4);
        var cell6 = row.insertCell(5);
        var cell7 = row.insertCell(6);
        cell1.innerHTML = i;
        i++;
        cell2.innerHTML = $('#ip_address').val();
        cell3.innerHTML = $('#port_no').val();
        cell4.innerHTML = $('#sensor_name').val();
        cell5.innerHTML = $('#desc').val();
        cell6.innerHTML = "stopped";
        cell7.innerHTML = " ";

        //$(this).modal("hide");
        $('myModal2').modal('show');
    });
})